

# Morgan Stanley Investment Funds (MS INVF)
## Emerging Leaders Equity Fund

August 2021

FOR PROFESSIONAL CLIENTS ONLY. NOT FOR ONWARD DISTRIBUTION

![Traffic lights on city street at night](url placeholder)

3681137 Exp. 07/31/2022

