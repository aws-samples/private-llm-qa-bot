

![Competitive Advantages of Morgan Stanley Investment Management](image.jpg)

Focus on continental sized markets with significant runway of growth

Target great businesses with strong quality characteristics

Concentrated portfolio of high conviction investments that can weather
the short-term market volatility

Leverage an experienced, well-resourced EM team for economic insights
to help minimize country risk

