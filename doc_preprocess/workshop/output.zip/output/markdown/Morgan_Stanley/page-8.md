

## Investment Process: Disciplined & Repeatable

Step 1:
Thematic Growth

Step 2: 
High-Quality Companies

Step 3:
Entry and Exit Prices

![Investment process diagram](image_url_placeholder.jpg)

This represents how the portfolio management team generally implements its investment process under normal market conditions.

The image shows a circular diagram titled "HIGH QUALITY THEMATIC GROWTH" with four key factors surrounding it:

- STRUCTURAL: Represented by a wrench and screwdriver icon
- PREDICTABLE: Represented by an arrow icon
- SCALABLE: Represented by a triangle icon
- REDUCED DOWNSIDE PARTICIPATION: Represented by a lock icon

