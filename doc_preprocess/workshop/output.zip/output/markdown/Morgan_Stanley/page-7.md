

# Hard to Time the Bottom in Markets

![Returns of MSCI EM Performance for $10,000 Investment Between January 1988 and December 2020](url placeholder)

Returns of MSCI EM
Performance of $10,000 Investment Between January, 1988 and December 2020

- Fully Invested: $305,162
- Missed 10 Best Months: $74,269
- Missed 20 Best Months: $24,097
- Missed 30 Best Months: $8,758
- Missed 40 Best Months: $3,672
- Missed 50 Best Months: $1,637

Source: Bloomberg, FactSet, Haver, MSIM EM Research as of December 31, 2020
For illustrative purposes only. Past performance is not a guarantee of future results and is not intended to predict or represent the performance of any Morgan Stanley investment
or strategy.

