

![Morgan Stanley Investment Management team structure](image_url_placeholder)

# Our Team

Based in New York, Singapore, Hong Kong & Mumbai

20+ YEARS AVERAGE PM EXPERIENCE · 14+ YEARS AVERAGE PM TENURE · 10+ YEARS AVERAGE ANALYST EXPERIENCE

## GEM & REGIONAL CO-LEADS
- Amay Hattangadi
- Paul Psaila
- Eric Carlson*

## CHINA
- Leon Sun
- Chelsea Hua
- Xijuan Sun*
- Jerry Peng

## ASIA EX JAPAN
- Rose Kim*
- Saurabh Mishra*
- Samson Hung
- Aayushi Kukreja

## LATIN AMERICA
- Jorge Chirino*
- Eduardo Wishun*

## CLIENT PORTFOLIO MANAGERS
- Amy Oldenburg, Chief Operating Officer
- Louise Teeple
- James Upton

## EMERGING LEADERS
- Vishal Gupta
- Arun Kapoor*

## ACTIVE INTERNATIONAL ALLOCATION
- Jitania Kandhari
- Ben Rozin
- Fil Wiseman
- Giovanni Urbanucci*

## NEXT GEN EM
- Steven Quattry
- Jorge Chirino*
- Cristina Dalton

## ESG RESEARCH:
- Candy Chao*

## PORTFOLIO SUPPORT
- Ashley Barone
- Cherie Stewart
- Satyam Sharma

| RUCHIR SHARMA | |
| --- | --- |
| Head of Emerging Markets | MSIM Chief Global Strategist |
| Jitania Kandhari | Head of Macro Research |
| Eli Wiseman | Tony Emerson |
| Stephan Gabillard | Amol Rajesh* |

(*) Denotes members of the ESG steering committee. As of July 31, 2021. PM tenure based on number of years with MSIM. Team members may change, without notice, from time to time.

