

![Morgan Stanley Investment Management History](image.jpg)

# Investment Pioneers in Emerging Markets Since 1986

## History of Morgan Stanley Investment Management offerings

| Year |            Offering            |
|------|--------------------------------|
| 1986 | ASIA                           |
| 1989 | INDIA                          |
| 1991 | GLOBAL EMERGING MARKETS        |
| 1992 | LATIN AMERICA                  |
| 1995 |                                |
| 2000 | EMEA                           |
| 2006 | CHINA A                        |
| 2007 | FRONTIER MARKETS               |
| 2011 | EMERGING MARKETS LEADERS       |
| 2018 | EMERGING MARKETS SPECIAL SITUATIONS |
| 2019 | CHINA EQUITY                   |
| 2020 | SUSTAINABLE ASIA EQUITY        |

### Timeline

- 1985
- 1990
- 1995
- 2000
- 2005
- 2010
- 2015
- 2020

### 1986
ACTIVE INTERNATIONAL ALLOCATION

Source: MSIM. For illustrative purposes only.

