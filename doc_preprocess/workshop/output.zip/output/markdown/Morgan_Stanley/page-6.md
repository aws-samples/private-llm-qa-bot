

# Compounders by Country – 5 Years

Number of Companies Compounded by >15% CAGR ($1BN+ mkt cap)
By Entity Country, Compound Annual Growth Rate 2016 – 2020 (in USD)

![Bar chart showing number of companies by country with >15% CAGR](url placeholder)

| Number of Companies >=1B Mcap | 2,165 | 225 | 114 | 217 | 62 | 167 | 50 | 57 | 58 | 60 | 61 | 69 | 15 | 37 | 18 | 16 | 60 | 30 | 41 | 13 | 11 | 4 | 48 | 29 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |

Source: FactSet, MSIM calculations. Data as of December 31, 2020. CAGR represents compound annual growth rate, calculated for 2016-2020 in USD terms. Market cap calculated as of December 31, 2015. Securities grouped by country of entity in FactSet.

## Chart Title: Number of Companies Compounded by >15% CAGR ($1BN+ mkt cap)

- China: 205
- India: 55
- Taiwan: 39
- Hong Kong: 30
- Brazil: 28
- South Korea: 21
- Russia: 20
- Indonesia: 11
- Saudi Arabia: 10
- South Africa: 10
- Thailand: 10
- Malaysia: 8
- Peru: 7
- Turkey: 5
- Argentina: 3
- Colombia: 3
- Kuwait: 2
- Nigeria: 2
- Mexico: 1
- Poland: 1
- Chile: 1
- Egypt: 1
- Greece: 1
- Hungary: 1
- Philippines: 1
- UAE: 1

