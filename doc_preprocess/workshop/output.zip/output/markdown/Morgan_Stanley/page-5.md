

# We See the Greatest Potential in Continental-Sized Markets

- Focused on 4 of the top 5 demographic markets -- Greater China, India, Brazil, Indonesia
- Large domestic consumption markets with a long runway for premiumization
- Legacy of high-quality entrepreneurship DNA, driven by systemic / societal needs

![Emerging Market Growth vs Population](url placeholder)

### Big picture: Twenty-six emerging market countries¹

#### Real GDP Growth vs Population, Bubble Sizes Proportional To Nominal GDP (USD)

| Country | GDP Growth (%) | Population (Billions) | Nominal GDP (USD) |
| --- | --- | --- | --- |
| Philippines | 6.2 | 0.107 | 330.8 |
| Malaysia | 4.7 | 0.032 | 354.3 |
| Egypt | 5.6 | 0.098 | 302.5 |
| Hungary | 4.9 | 0.01 | 160.8 |
| Poland | 5.1 | 0.038 | 586.5 |
| Pakistan | 3.3 | 0.216 | 313 |
| Colombia | 3.3 | 0.049 | 330 |
| Peru | 4 | 0.032 | 226.8 |
| Chile | 4 | 0.018 | 294.2 |
| Thailand | 4.1 | 0.069 | 505.9 |
| Korea | 2.7 | 0.051 | 1628.1 |
| Russia | 1.3 | 0.144 | 1658.6 |
| Taiwan | 2.7 | 0.024 | 586.1 |
| South Africa | 0.8 | 0.058 | 368.3 |
| UAE | 1.7 | 0.01 | 421.1 |
| Greece | 1.9 | 0.011 | 218.1 |
| Qatar | 2.6 | 0.003 | 174.6 |
| Czech Republic | 2.9 | 0.011 | 246 |
| Turkey | 0.9 | 0.082 | 771.4 |
| Saudi Arabia | 0.3 | 0.034 | 782.5 |
| Mexico | 0.4 | 0.127 | 1221 |
| Argentina | -2.5 | 0.045 | 518.8 |
| Brazil | 1.1 | 0.21 | 1869.6 |
| Indonesia | 5.2 | 0.268 | 1118.8 |
| India | 6.8 | 1.366 | 2716.7 |
| China - Growth, Demographics, Rich Entrepreneurship Culture | 6.1 | 1.393 | 14092.5 |

**Notes**
¹Based on the 26 countries in the MSCI Emerging Market Index Source: Morgan Stanley Investment Management, MSCI as of September 2019.
This represents how the portfolio management team generally implements its investment process under normal market conditions.

