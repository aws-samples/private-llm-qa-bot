

# Our Global Equity Strategies

Assets Under Management (1) (MM) as of August 31, 2021

![Information on Global Equity Strategies by Morgan Stanley Investment Management](image_url_placeholder)

## GLOBAL EMERGING MARKETS

| Strategy | Assets Under Management (MM) |
| --- | --- |
| Global Emerging Markets | $7,246 |
| Next Gen Emerging Markets | $333 |
| Emerging Markets Leaders | $2,339 |
| Emerging Markets Special Situations | $788 |

## REGIONAL/COUNTRY

| Strategy | Assets Under Management (MM) |
| --- | --- |
| Asia(2) | $5,116 |
| China(3) | $1,070 |
| EMEA | $93 |
| India | $461 |
| Latin America | $338 |

## SUSTAINABLE

* Sustainable Asia Equity: $46

## ALL COUNTRY GLOBAL MARKETS  

| Strategy | Assets Under Management (MM) |
| --- | --- |
| Active International Allocation | $247 |
| Global Equity Allocation | $1,140 |

### Pie Chart: TOTAL AUM

* ALL COUNTRY WORLD: 1,387 MM
* SUSTAINABLE: 46 MM
* EM REGIONAL/COUNTRY: 7,078 MM
* GLOBAL EMERGING MARKETS: 10,706 MM

Total AUM: $19,217 MM

Source: Morgan Stanley Investment Management
1. Assets are presented in millions of US dollars. The figure includes assets managed globally under these strategies within a number of separate products, jurisdictions and mandates. 
2. Includes developed Asia as defined by MSCI.
3. China includes All China, China A-share and Hong Kong assets.
This represents how the portfolio management team generally implements its investment process under normal market conditions.

